"""Prints the element given as input."""


def welcome_user():
    """Возвращает имя пользователя Returns: name."""
    name = input('Make I have your name?')
    return name
