"""Games for terminal."""
