"""Функции для игр."""


print('Welcome to the Brain Games!')
name = input('Make I have your name? ')
print('Hello, {0}!'.format(name))
